create function hc_capture_insert_from_row(source_row hstore, table_name character varying, excluded_cols text[] DEFAULT ARRAY[]::text[]) returns integer
    language plpgsql
as
$$
        DECLARE
            excluded_cols_standard text[] = ARRAY['_hc_lastop', '_hc_err']::text[];
            retval int;

        BEGIN
            -- VERSION 1 --

            IF (source_row -> 'id') IS NULL THEN
                -- source_row is required to have an int id value
                RETURN NULL;
            END IF;

            excluded_cols_standard := array_remove(
                array_remove(excluded_cols, 'id'), 'sfid') || excluded_cols_standard;
            INSERT INTO "devint"."_trigger_log" (
                action, table_name, txid, created_at, state, record_id, values)
            VALUES (
                'INSERT', table_name, txid_current(), clock_timestamp(), 'NEW',
                (source_row -> 'id')::int,
                source_row - excluded_cols_standard
            ) RETURNING id INTO retval;
            RETURN retval;
        END;
        $$;

alter function hc_capture_insert_from_row(hstore, varchar, text[]) owner to snzjhcnrpzgzrh;

