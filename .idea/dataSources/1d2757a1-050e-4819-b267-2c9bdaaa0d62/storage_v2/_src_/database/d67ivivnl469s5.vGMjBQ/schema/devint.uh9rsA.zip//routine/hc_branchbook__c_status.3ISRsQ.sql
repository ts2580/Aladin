create function hc_branchbook__c_status() returns trigger
    language plpgsql
as
$$
                    BEGIN
                      IF (get_xmlbinary() = 'base64') THEN  -- user op
                        NEW._hc_lastop = 'PENDING';
                        NEW._hc_err = NULL;
                        RETURN NEW;
                      ELSE  -- connect op
                        IF (TG_OP = 'UPDATE' AND NEW._hc_lastop IS NOT NULL AND NEW._hc_lastop != OLD._hc_lastop) THEN
                            RETURN NEW;
                        END IF;

                        NEW._hc_lastop = 'SYNCED';
                        NEW._hc_err = NULL;
                        RETURN NEW;
                      END IF;
                    END;
                 $$;

alter function hc_branchbook__c_status() owner to snzjhcnrpzgzrh;

