create view pg_group(groname, grosysid, grolist) as
SELECT pg_authid.rolname                                   AS groname,
       pg_authid.oid                                       AS grosysid,
       ARRAY(SELECT pg_auth_members.member
             FROM pg_auth_members
             WHERE pg_auth_members.roleid = pg_authid.oid) AS grolist
FROM pg_authid
WHERE NOT pg_authid.rolcanlogin;

alter table pg_group
    owner to postgres;

grant select on pg_group to public;

