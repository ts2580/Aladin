create procedure fn_updttotprc()
    language plpgsql
as
$$
declare 
begin

	update devint.branch__c ib
	set totalpriceint__c = eb.prc
	from (
		select branch as branch, sum(minprice::int) as prc
		from devext.branchbook b
		group by branch
	) eb
	where ib.sfid = eb.branch;
	
END;
$$;

alter procedure fn_updttotprc() owner to snzjhcnrpzgzrh;

