create procedure fn_delbook()
    language plpgsql
as
$$
declare 
BEGIN
	truncate devext.branchbook;
	truncate devint."_trigger_log";
	truncate devint."_trigger_log_archive";
	END;
$$;

alter procedure fn_delbook() owner to snzjhcnrpzgzrh;

