create view pg_stat_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_scan, idx_tup_read, idx_tup_fetch) as
SELECT pg_stat_all_indexes.relid,
       pg_stat_all_indexes.indexrelid,
       pg_stat_all_indexes.schemaname,
       pg_stat_all_indexes.relname,
       pg_stat_all_indexes.indexrelname,
       pg_stat_all_indexes.idx_scan,
       pg_stat_all_indexes.idx_tup_read,
       pg_stat_all_indexes.idx_tup_fetch
FROM pg_stat_all_indexes
WHERE (pg_stat_all_indexes.schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND pg_stat_all_indexes.schemaname !~ '^pg_toast'::text;

alter table pg_stat_user_indexes
    owner to postgres;

grant select on pg_stat_user_indexes to public;

