create function pg_bbi_bbe() returns trigger
    language plpgsql
as
$$

DECLARE

begin

	INSERT INTO devext.branchbook 
    (
     book,
     volume,
     name,
     branch,
     branchname,
     booklink,
     minprice
    )
    VALUES
    (
      NEW.book__c,
      NEW.volume__c,
      NEW.name,
      NEW.branch__c,
      NEW.branchname__c,
      NEW.booklink__c,
      NEW.minprice__c
    );
   
   delete from devint.branchbook__c 
   where id = NEW.Id;

    RETURN NULL;

end;
$$;

alter function pg_bbi_bbe() owner to snzjhcnrpzgzrh;

