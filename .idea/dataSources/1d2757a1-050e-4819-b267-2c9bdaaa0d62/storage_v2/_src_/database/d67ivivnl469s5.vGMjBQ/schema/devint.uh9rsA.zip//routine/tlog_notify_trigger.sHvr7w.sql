create function tlog_notify_trigger() returns trigger
    language plpgsql
as
$$
            DECLARE
             BEGIN
               -- VERSION 1 --
               PERFORM pg_notify('devint.hc_trigger_log', 'ping');
               RETURN new;
             END;
            $$;

alter function tlog_notify_trigger() owner to snzjhcnrpzgzrh;

