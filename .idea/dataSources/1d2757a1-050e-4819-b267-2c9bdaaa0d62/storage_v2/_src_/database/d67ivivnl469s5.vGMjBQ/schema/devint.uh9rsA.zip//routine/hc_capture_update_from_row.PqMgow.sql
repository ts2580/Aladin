create function hc_capture_update_from_row(source_row hstore, table_name character varying, columns_to_include text[] DEFAULT ARRAY[]::text[]) returns integer
    language plpgsql
as
$$
        DECLARE
            excluded_cols_standard text[] = ARRAY['_hc_lastop', '_hc_err']::text[];
            excluded_cols text[];
            retval int;

        BEGIN
            -- VERSION 1 --

            IF (source_row -> 'id') IS NULL THEN
                -- source_row is required to have an int id value
                RETURN NULL;
            END IF;

            IF array_length(columns_to_include, 1) <> 0 THEN
                excluded_cols := array(
                    select skeys(source_row)
                    except
                    select unnest(columns_to_include)
                );
            END IF;
            excluded_cols_standard := excluded_cols || excluded_cols_standard;
            INSERT INTO "devint"."_trigger_log" (
                action, table_name, txid, created_at, state, record_id, sfid, values, old)
            VALUES (
                'UPDATE', table_name, txid_current(), clock_timestamp(), 'NEW',
                (source_row -> 'id')::int, source_row -> 'sfid',
                source_row - excluded_cols_standard, NULL
            ) RETURNING id INTO retval;
            RETURN retval;
        END;
        $$;

alter function hc_capture_update_from_row(hstore, varchar, text[]) owner to snzjhcnrpzgzrh;

