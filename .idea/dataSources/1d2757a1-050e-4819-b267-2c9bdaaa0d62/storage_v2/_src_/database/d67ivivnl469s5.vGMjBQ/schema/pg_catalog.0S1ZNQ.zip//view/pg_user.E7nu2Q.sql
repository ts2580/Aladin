create view pg_user (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) as
SELECT pg_shadow.usename,
       pg_shadow.usesysid,
       pg_shadow.usecreatedb,
       pg_shadow.usesuper,
       pg_shadow.userepl,
       pg_shadow.usebypassrls,
       '********'::text AS passwd,
       pg_shadow.valuntil,
       pg_shadow.useconfig
FROM pg_shadow;

alter table pg_user
    owner to postgres;

grant select on pg_user to public;

